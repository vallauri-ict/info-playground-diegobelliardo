﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Es6p115
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] nomi = new string[]
           {
                "Marco", "Luca", "Giovanni", "Alessandro", "Francesco",
                "Matteo", "Andrea", "Roberto", "Giuseppe", "Daniele",
                "Davide", "Simone", "Stefano", "Antonio", "Giulio",
                "Federico", "Paolo", "Leonardo", "Giorgio", "Salvatore"
           };

            string[] cognomi = new string[]
            {
                "Rossi", "Bianchi", "Verdi", "Neri", "Gialli",
                "Marini", "Romano", "Esposito", "Ferrari", "Conti",
                "Giordano", "Ricci", "Lombardi", "Sorrentino", "Barbieri",
                "Corsi", "De Luca", "Vitali", "Pellegrini", "Santoro"
            };

            string[] squadre = new string[]
            {
                "Juventus", "Roma", "Roma", "Milan", "Milan",
                "Juventus", "Juventus", "Roma", "Napoli", "Milan",
                "Juventus", "Juventus", "Juve", "Napoli", "Milan",
                "Juventus", "Roma", "Roma", "Napoli", "Milan"
            };
            string[] temp = new string[] { "Juventus", "Roma", "Milan", "Napoli" };
            int[] numeri = new int[4];
           
            for(int i = 0; i < 4; i++)
            {
                for(int j = 0; j < squadre.Length; j++)
                {
                    if (squadre[j] == temp[i])
                    {
                        numeri[i] = numeri[i] + 1;
                    }
                }
            }

            BubbleSort(numeri, temp);

            Console.WriteLine("SQUADRE: \n");
            for(int i=0;i<4;i++)
            {
                Console.WriteLine($"{temp[i]}: {numeri[i]}");
            }

            Console.ReadKey();

        }


        private static void BubbleSort(int[] numeri, string[]temp)
        {
            int n = numeri.Length;
            for (int i = 0; i < n-1; i++)
            {
                for (int j = 0; j < n-1 - i; j++)
                {
                    if (numeri[j] < numeri[j+1])
                    {
                        int aus = numeri[j];
                        numeri[j] = numeri[j + 1];
                        numeri[j + 1] = aus;


                        string aus2 = temp[j];
                        temp[j] = temp[j + 1];
                        temp[j + 1] = aus2;
                    }
                }
            }
        }
    }
}
